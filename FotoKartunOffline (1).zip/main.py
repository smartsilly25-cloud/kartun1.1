import os
import sys
import threading
import time

# --- aman untuk mode --noconsole (stdout/stderr bisa None) ---
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

# folder model disimpan di samping aplikasi (diunduh sekali saja)
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(APP_DIR, "models")
os.makedirs(MODEL_DIR, exist_ok=True)
os.environ["HF_HOME"] = MODEL_DIR
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import customtkinter as ctk
from PIL import Image
from tkinter import filedialog, messagebox

EXTS = (".jpg", ".jpeg", ".png", ".webp", ".bmp")

MODELS = [
    "Lykon/dreamshaper-8",
    "stable-diffusion-v1-5/stable-diffusion-v1-5",
]

POSITIVE = (
    "cartoon illustration of the same person, bold clean black outlines, "
    "cel shading, flat vivid colors, vector art style, highly detailed, masterpiece"
)
NEGATIVE = (
    "photo, photorealistic, realistic skin texture, blurry, lowres, deformed, "
    "bad anatomy, extra fingers, text, watermark"
)


HASIL_DIR = os.path.join(APP_DIR, "Hasil")


def dir_size(path):
    total = 0
    for root, _, fs in os.walk(path):
        for f in fs:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


class Cancelled(Exception):
    pass


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Foto ke Kartun (Offline)")
        self.geometry("940x680")
        ctk.set_appearance_mode("dark")

        self.files = []
        self.outdir = HASIL_DIR
        self.cancel = False
        self.running = False
        self.pipe = None
        self.pipe_model = None

        # ---------- baris 1: pilih foto ----------
        r1 = ctk.CTkFrame(self)
        r1.pack(fill="x", padx=12, pady=(12, 4))
        ctk.CTkButton(r1, text="Pilih Foto", width=110, command=self.pick_files).pack(side="left", padx=6, pady=6)
        ctk.CTkButton(r1, text="Pilih Folder", width=110, command=self.pick_folder).pack(side="left", padx=6)
        ctk.CTkButton(r1, text="Folder Hasil", width=110, command=self.pick_outdir).pack(side="left", padx=6)
        self.info = ctk.CTkLabel(r1, text=f"Belum ada foto. Hasil → {HASIL_DIR}", anchor="w")
        self.info.pack(side="left", padx=10, fill="x", expand=True)

        # ---------- baris 2: pengaturan ----------
        r2 = ctk.CTkFrame(self)
        r2.pack(fill="x", padx=12, pady=4)

        ctk.CTkLabel(r2, text="Model:").grid(row=0, column=0, padx=6, pady=6)
        self.model_box = ctk.CTkComboBox(r2, values=MODELS, width=300)
        self.model_box.set(MODELS[0])
        self.model_box.grid(row=0, column=1, padx=6)

        ctk.CTkLabel(r2, text="Ukuran:").grid(row=0, column=2, padx=6)
        self.size_box = ctk.CTkOptionMenu(r2, values=["384", "512", "640"], width=80)
        self.size_box.set("512")
        self.size_box.grid(row=0, column=3, padx=6)

        ctk.CTkLabel(r2, text="Langkah:").grid(row=0, column=4, padx=6)
        self.steps_box = ctk.CTkOptionMenu(r2, values=["15", "20", "25", "30"], width=80)
        self.steps_box.set("20")
        self.steps_box.grid(row=0, column=5, padx=6)

        ctk.CTkLabel(r2, text="Kekuatan kartun:").grid(row=1, column=0, padx=6, pady=6)
        self.strength = ctk.CTkSlider(r2, from_=0.40, to=0.80, number_of_steps=40, width=300,
                                      command=self._on_strength)
        self.strength.set(0.60)
        self.strength.grid(row=1, column=1, padx=6)
        self.strength_lbl = ctk.CTkLabel(r2, text="0.60 (makin tinggi = makin kartun, wajah makin berubah)")
        self.strength_lbl.grid(row=1, column=2, columnspan=4, padx=6, sticky="w")

        # ---------- baris 3: tombol jalan ----------
        r3 = ctk.CTkFrame(self)
        r3.pack(fill="x", padx=12, pady=4)
        self.start_btn = ctk.CTkButton(r3, text="Mulai", width=110, command=self.start)
        self.start_btn.pack(side="left", padx=6, pady=6)
        self.stop_btn = ctk.CTkButton(r3, text="Berhenti", width=110, fg_color="#a33", command=self.stop,
                                      state="disabled")
        self.stop_btn.pack(side="left", padx=6)
        self.bar = ctk.CTkProgressBar(r3, width=260)
        self.bar.set(0)
        self.bar.pack(side="left", padx=10)
        self.status = ctk.CTkLabel(r3, text="Siap.", anchor="w")
        self.status.pack(side="left", padx=6, fill="x", expand=True)

        # ---------- pratinjau ----------
        panes = ctk.CTkFrame(self)
        panes.pack(fill="both", expand=True, padx=12, pady=6)
        panes.columnconfigure((0, 1), weight=1)
        panes.rowconfigure(0, weight=1)
        self.left = ctk.CTkLabel(panes, text="Foto asli")
        self.left.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.right = ctk.CTkLabel(panes, text="Hasil kartun")
        self.right.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)

    # ---------------- util UI ----------------
    def _on_strength(self, v):
        self.strength_lbl.configure(text=f"{float(v):.2f} (makin tinggi = makin kartun, wajah makin berubah)")

    def ui(self, fn, *a):
        self.after(0, fn, *a)

    def set_status(self, t):
        self.ui(lambda: self.status.configure(text=t))

    def set_bar(self, v):
        self.ui(lambda: self.bar.set(max(0.0, min(1.0, v))))

    def _show(self, label, img):
        im = img.copy()
        im.thumbnail((420, 400))
        c = ctk.CTkImage(light_image=im, dark_image=im, size=im.size)
        label.configure(image=c, text="")
        label.image = c

    # ---------------- pilih file ----------------
    def _set_files(self, files):
        self.files = files
        self.info.configure(text=f"{len(files)} foto  →  {self.outdir}")
        if files:
            try:
                self._show(self.left, Image.open(files[0]).convert("RGB"))
            except Exception:
                pass

    def pick_files(self):
        fs = filedialog.askopenfilenames(filetypes=[("Gambar", "*.jpg *.jpeg *.png *.webp *.bmp")])
        if fs:
            self._set_files(list(fs))

    def pick_folder(self):
        d = filedialog.askdirectory()
        if not d:
            return
        fs = sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(EXTS))
        if not fs:
            messagebox.showinfo("Folder", "Tidak ada gambar di folder itu.")
            return
        self._set_files(fs)

    def pick_outdir(self):
        d = filedialog.askdirectory()
        if d:
            self.outdir = d
            self.info.configure(text=f"{len(self.files)} foto  →  {self.outdir}")

    # ---------------- kontrol ----------------
    def start(self):
        if self.running:
            return
        if not self.files:
            messagebox.showwarning("Foto", "Pilih foto atau folder dulu.")
            return
        os.makedirs(self.outdir, exist_ok=True)
        self.cancel = False
        self.running = True
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        params = dict(
            model=self.model_box.get().strip(),
            size=int(self.size_box.get()),
            steps=int(self.steps_box.get()),
            strength=float(self.strength.get()),
        )
        threading.Thread(target=self._run, args=(list(self.files), self.outdir, params), daemon=True).start()

    def stop(self):
        self.cancel = True
        self.set_status("Menghentikan...")

    def _finish(self):
        self.running = False
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")

    # ---------------- model ----------------
    def _load_pipe(self, model_id):
        if self.pipe is not None and self.pipe_model == model_id:
            return self.pipe

        stop_evt = threading.Event()

        def monitor():
            start_size = dir_size(MODEL_DIR)
            last, last_t, idle = start_size, time.time(), 0
            self.set_status("Menyiapkan model...")
            while not stop_evt.wait(1.0):
                cur, now = dir_size(MODEL_DIR), time.time()
                speed = (cur - last) / max(1e-6, now - last_t) / 1e6
                got = (cur - start_size) / 1e9
                last, last_t = cur, now
                if speed > 0.05:
                    idle = 0
                    self.set_status(
                        f"MENGUNDUH model: {got:.2f} GB terunduh ({speed:.1f} MB/s) — total ±2-4 GB"
                    )
                else:
                    idle += 1
                    if idle >= 4:
                        self.set_status("Memuat model ke memori (tidak sedang mengunduh)... mohon tunggu")

        self.ui(lambda: (self.bar.configure(mode="indeterminate"), self.bar.start()))
        threading.Thread(target=monitor, daemon=True).start()
        try:
            import torch
            from diffusers import StableDiffusionImg2ImgPipeline, DPMSolverMultistepScheduler
            from diffusers.utils import logging as dlog

            dlog.disable_progress_bar()
            torch.set_num_threads(max(1, os.cpu_count() or 4))

            kw = dict(torch_dtype=torch.float32, safety_checker=None, requires_safety_checker=False,
                      use_safetensors=True)
            try:
                pipe = StableDiffusionImg2ImgPipeline.from_pretrained(model_id, variant="fp16", **kw)
            except Exception:
                pipe = StableDiffusionImg2ImgPipeline.from_pretrained(model_id, **kw)
            pipe.scheduler = DPMSolverMultistepScheduler.from_config(
                pipe.scheduler.config,
                algorithm_type="dpmsolver++",
                solver_order=2,
                final_sigmas_type="sigma_min",
                use_karras_sigmas=False,
            )
            pipe.set_progress_bar_config(disable=True)
            pipe.to("cpu")
            self.pipe, self.pipe_model = pipe, model_id
            return pipe
        finally:
            stop_evt.set()
            self.ui(lambda: (self.bar.stop(), self.bar.configure(mode="determinate"), self.bar.set(0)))

    # ---------------- proses ----------------
    @staticmethod
    def _fit(img, target):
        w, h = img.size
        s = target / max(w, h)
        nw = max(64, int(round(w * s / 8)) * 8)
        nh = max(64, int(round(h * s / 8)) * 8)
        return img.resize((nw, nh), Image.LANCZOS)

    def _run(self, files, outdir, p):
        try:
            import torch
            pipe = self._load_pipe(p["model"])
            total = len(files)
            done = 0
            for i, f in enumerate(files, 1):
                if self.cancel:
                    break
                base = os.path.splitext(os.path.basename(f))[0]
                out_path = os.path.join(outdir, base + "_kartun.png")
                if os.path.exists(out_path):
                    done += 1
                    continue
                try:
                    src = Image.open(f).convert("RGB")
                except Exception:
                    continue
                self.ui(self._show, self.left, src)
                img = self._fit(src, p["size"])
                eff = max(1, int(p["steps"] * p["strength"]))
                t0 = time.time()

                def cb(pipe_, step, t, kwargs, _i=i):
                    if self.cancel:
                        raise Cancelled()
                    el = int(time.time() - t0)
                    self.set_status(f"Foto {_i}/{total} — langkah {step + 1}/{eff} — {el // 60}:{el % 60:02d} berlalu")
                    self.set_bar(((_i - 1) + (step + 1) / eff) / total)
                    return kwargs

                gen = torch.Generator("cpu").manual_seed(1234)
                try:
                    with torch.inference_mode():
                        res = pipe(
                            prompt=POSITIVE,
                            negative_prompt=NEGATIVE,
                            image=img,
                            strength=p["strength"],
                            num_inference_steps=p["steps"],
                            guidance_scale=7.0,
                            generator=gen,
                            callback_on_step_end=cb,
                        ).images[0]
                except Cancelled:
                    break
                res.save(out_path)
                done += 1
                self.ui(self._show, self.right, res)
            msg = "Dihentikan." if self.cancel else "Selesai."
            self.set_status(f"{msg} {done}/{total} foto → {outdir}")
            if not self.cancel:
                self.set_bar(1.0)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            self.set_status("Gagal.")
            self.ui(lambda: messagebox.showerror("Error", err))
        finally:
            self.ui(self._finish)


if __name__ == "__main__":
    App().mainloop()
